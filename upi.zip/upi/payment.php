<?php 
include 'cart_code.php';
?>
<html>
    <head>
        <title>Online Shopping Site for Mobiles, Electronics, Furniture, Grocery</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="header.css">
        <link rel="stylesheet" href="home.css">
        <link rel="stylesheet" href="payment.css">
        <link rel="apple-touch-icon" href="logo192.png">
        <link rel="icon" href="favicon.ico">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <div class="header2">
          <div class="hamicon"><i class="fa fa-arrow-left"></i></div>
          <div class="cart"><i class="fa fa-search"></i><i class="fa fa-bell"><span>1</span></i>
          <i class="fa fa-shopping-cart"><span>
                  <?php 
                   if(isset($_SESSION['shopping_cart'])){
                       echo count($_SESSION['shopping_cart']);
                   }else{
                       echo "0";
                   }
                  ?>
              </span></i></div>
        </div>
        
        <div class="payment">
          <div class="select">
            <p>Select a payment method</p>
          </div>
          <p class="ends">Offer ends in <span style="color: rgb(251, 100, 27);" id="demo">00:00</span></p>
          <div class="method"><input type="radio" name="pay" id="paytem" checked>
            <p>Paytm</p>
          </div>
          <div class="method"><input type="radio" name="pay" id="phonepe">
            <p>Phonepe</p>
          </div>
          <div class="method" disabled=""><input type="radio" name="pay" id="" disabled="">
            <p style="color: gray;">Cash on Delivery</p>
          </div>
          <?php
          $item_qty = 0;
          $item_total = 0;
          if(isset($_SESSION['shopping_cart'])){
             foreach($_SESSION['shopping_cart'] as $key => $value){
                 
                $item_total = $item_total + $value['item_price'];
                $item_qty = $item_qty + $value['item_quantity'];
                ?>
                <div class="p-detail"><img src="<?= $value['item_img'];?>" alt="">
                <div class="det">
                  <p class="price">₹<?= $value['item_price'];?><span>₹<?= $value['item_quity_select'];?></span></p>
                  <p class="name"><?= $value['item_name'];?></p>
                  <p class="qty">Quantity: <?= $value['item_quantity'];?></p>
                </div>
              </div>
                <?php
             }
          }
          ?>
          
          <a  id="paybtn" href="paytmmp://pay?pa=7388023958@ybl&amp;pn=Paytm&amp;tn=Transfer-to-products&amp;am=<?=$item_total;?>&amp;mode=02&amp;cu=INR&amp;tr'">Place
            your Order and Pay</a>
           
            <img src="https://couponswala.com/blog/wp-content/uploads/2022/06/big-bachat-dhamal-sale.jpg"
            alt="" style="width: 90vw; margin: 30px 5vw;">
          <div class="price-detail">
            <p>PRICE DETAILS</p>
            <div>
              <p>Price(<?=$item_qty;?> item)</p>
              <p>₹<?=$item_total;?></p>
            </div>
            <div>
              <p>Delivery Charges</p>
              <p style="color: rgb(56, 142, 60);">Free</p>
            </div>
            <div>
              <p>Amount Payable</p>
              <p>₹<?=$item_total;?></p>
            </div>
          </div><img src="payf.92a1b0522f980ec2db51.jpg" alt="" class="payf"
            style="width: 100%; margin-top: 12px;">
        </div>

<script>
document.getElementById("paytem").onclick = function() {
  fun()
};

document.getElementById("phonepe").onclick = function() {
  fun1()
};


function fun() {
  document.getElementById("paybtn").setAttribute("href", "paytmmp://pay?pa=7388023958@ybl&amp;pn=Paytm&amp;tn=Transfer-to-products&amp;am=<?=$item_total;?>&amp;mode=02&amp;cu=INR&amp;tr'");
}

function fun1() {
  document.getElementById("paybtn").setAttribute("href", "phonepe://pay?pa=7388023958@ybl&amp;pn=Paytm&amp;tn=Transfer-to-products&amp;am=<?=$item_total;?>&amp;mode=02&amp;cu=INR&amp;tr'");
}

</script>

<?php 
date_default_timezone_set("Asia/Calcutta");
$now = time();
$ten_minutes = $now + (20 * 60);
$endDate = date('M d, Y H:i:s', $ten_minutes);
?>
<script>
// Set the date we're counting down to
var countDownDate = new Date("<?= $endDate;?>").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();
    
  // Find the distance between now and the count down date
  var distance = countDownDate - now;
    
  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
  // Output the result in an element with id="demo"
  document.getElementById("demo").innerHTML = minutes + "m " + seconds + "s ";
    
  // If the count down is over, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "EXPIRED";
  }
}, 1000);
</script>
</body>
</html>