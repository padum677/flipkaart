<?php 
include 'cart_code.php';
?>
<html>
    <head>
        <title>Online Shopping Site for Mobiles, Electronics, Furniture, Grocery</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="header.css">
        <link rel="stylesheet" href="home.css">
        <link rel="stylesheet" href="address.css">
        <link rel="apple-touch-icon" href="logo192.png">
        <link rel="icon" href="favicon.ico">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <div class="header2">
          <div class="hamicon"><i class="fa fa-arrow-left"></i></div>
          <div class="cart"><i class="fa fa-search"></i><i class="fa fa-bell"><span>1</span></i><i
              class="fa fa-shopping-cart"><span>
                  <?php 
                   if(isset($_SESSION['shopping_cart'])){
                       echo count($_SESSION['shopping_cart']);
                   }else{
                       echo "0";
                   }
                  ?>
              </span></i></div>
        </div>
        
        <div class="address">
          <div class="heading">
            <h1>Address</h1>
          </div>
          <div class="form" ><input type="text" placeholder="Full Name"><input type="number" name="" id=""
              placeholder="Mobile Number"><input type="number" name="" id="" placeholder="Pin Code"><input type="text"
              placeholder="Flat,House no,Building,Company"><input type="text"
              placeholder="Area,Colony,Street,Sector,Village"><input type="text" placeholder="Town/City"><input type="text"
              placeholder="State"><a href="payment.php">Proceed to Pay</a></div>
          <p>Term &amp; Conditions</p>
        </div>

    </body>
</html>