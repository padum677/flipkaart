<?php
setcookie("admin_user","$u",time()-3600*24*30, '/');
unset($_COOKIE['admin_user']);
session_start();
unset($_SESSION['admin_username']);
unset($_SESSION['login']);	 
session_unset();
session_destroy();
header('location:login.php');
exit();

?>