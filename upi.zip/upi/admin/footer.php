<footer class="main-footer">
<div class="pull-right hidden-xs"> <b>Version</b> 1.3</div>
<strong>&copy; <?php echo date('Y'); ?> <a href="#"><?php echo $company_name?></a>.</strong> All rights reserved.  Developed By <a href="https://www.raksasolution.com/" style="">Raksa Solution</a>
</footer>