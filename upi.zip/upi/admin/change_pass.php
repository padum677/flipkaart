<!DOCTYPE html>
<html lang="en">
<head>
<?php
include 'header.php';
//window.location.replace('loc_add.php');
?>
<title>CHANGE PASSWORD - <?php echo $company_name;?></title>
</head>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
<?php
include 'top-nav.php';
?>
<?php
include 'sidebar-left.php';
include('connection.php');

if(isset($_POST['update_password'])){
   $old_password = $_POST['old_password'];
   $new_password = $_POST['new_password'];
   $date = date('Y-m-d H:i:s');
   
    $admin_query = "select * from admin";
    $admin_result = mysqli_query($con, $admin_query);
    while($admin_row = mysqli_fetch_array($admin_result)){
        $password = $admin_row['password'];
    }
    
    if($old_password == $password){
        
        $admin_query = "UPDATE `admin` SET `password`= '$new_password' , `modified` = '$date' WHERE id = 1";
        $admin_result = mysqli_query($con, $admin_query);
        if($admin_result){
            echo"<script type='text/javascript'>alert('Password Updated');window.location.replace('change_pass.php');</script>";
        }else{
            echo"<script type='text/javascript'>alert('Something wrong!');window.location.replace('change_pass.php');</script>";
        }
    
    }else{
        echo"<script type='text/javascript'>alert('Please Enter Correct Old Password');window.location.replace('change_pass.php');</script>";
    }

}
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
                <!-- Content Header (Page header) -->
               <section class="content-header">
                    <div class="header-icon"><i class="fa fa-key"></i></div>
                    <div class="header-title">
                        <h1>Change Password</h1>
                        <small>Here you can assign order to  Change Password.</small>
                        <ol class="breadcrumb hidden-xs">
                            <li><a href="index.php"><i class="pe-7s-home"></i>Dashboard</a></li>
                            <li class="active">Password</li>
                        </ol>
                    </div>
                </section>
				    <!-- Main content -->
                <section class="content">
                    <div class="row">
                        <!-- Form controls -->
                        <div class="col-sm-12">
                            <div class="panel panel-bd lobidrag">
                            
                                <div class="panel-body">
                       <form method="post" action="<?php echo "$self"; ?>">
                        <div class="col-md-6">
                        	<div class="form-group">
                        	<label>Old Password*</label>
                        	<input type="password" class="form-control" name="old_password" placeholder"ENTER OLD PASSWORD" required="yes">
                        	</div>
                        </div>
                        	
                        <div class="col-md-6">
                        	<div class="form-group">
                        	<label>New Password</label>
                        	<input type="password" class="form-control" name="new_password" placeholder"ENTER NEW PASSWORD" required="yes">
                        	</div>
</div>
<div class="col-md-12">
 <button class="btn btn-grad" type="submit" name="update_password" style"width:100%;" >UPDATE PASSWORD</button>   
    </div>
                        	
                       </div>
                       </form>
                                     </div>
                                 </div>
                             </div>
                         </div>
                     </section> <!-- /.content -->
				    <!-- Main content -->
               
</div> <!-- /.content-wrapper -->
<?php
include 'footer.php';
?>
</div> <!-- ./wrapper -->

<?php
include 'footer-script.php';
?>	
</body>
</html>