<?php
include 'info.php';
include 'connection.php';
date_default_timezone_set('Asia/Kolkata');
?>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

<!-- Favicon and touch icons -->
<link rel="shortcut icon" href="<?php echo $favicon;?>" type="image/x-icon">
<!-- Start Global Mandatory Style
=====================================================================-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/js/bootstrap-select.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/css/bootstrap-select.min.css" rel="stylesheet" />
<!-- jquery-ui css -->
<link href="assets/plugins/jquery-ui-1.12.1/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
<!-- Bootstrap -->
<link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<!-- Bootstrap rtl -->
<!--<link href="assets/bootstrap-rtl/bootstrap-rtl.min.css" rel="stylesheet" type="text/css"/>-->
<!-- Lobipanel css -->
<link href="assets/plugins/lobipanel/lobipanel.min.css" rel="stylesheet" type="text/css"/>
<!-- Pace css -->
<link href="assets/plugins/pace/flash.css" rel="stylesheet" type="text/css"/>
<!-- Font Awesome -->
<link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
<!-- Pe-icon -->
<link href="assets/pe-icon-7-stroke/css/pe-icon-7-stroke.css" rel="stylesheet" type="text/css"/>
<!-- Themify icons -->
<link href="assets/themify-icons/themify-icons.css" rel="stylesheet" type="text/css"/>
<!-- End Global Mandatory Style
=====================================================================-->
<!-- Start page Label Plugins 
=====================================================================-->
<!-- Toastr css -->
<link href="assets/plugins/toastr/toastr.css" rel="stylesheet" type="text/css"/>
<!-- Emojionearea -->
<link href="assets/plugins/emojionearea/emojionearea.min.css" rel="stylesheet" type="text/css"/>
<!-- Monthly css -->
<link href="assets/plugins/monthly/monthly.css" rel="stylesheet" type="text/css"/>
<!-- End page Label Plugins 
=====================================================================-->
<!-- Start Theme Layout Style
=====================================================================-->
<!-- Theme style -->
<link href="assets/dist/css/stylehealth.min.css" rel="stylesheet" type="text/css"/>

<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<!--<link href="assets/dist/css/stylehealth-rtl.css" rel="stylesheet" type="text/css"/>-->
<!-- End Theme Layout Style
=====================================================================-->



<!--Data Table Script/CSS Start-->
<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="http://www.datatables.net/rss.xml">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.7.0/css/buttons.dataTables.min.css">

<!-- Data Table Script/CSS Ends
=====================================================================-->
<style>
@media (max-width: 550px){
.items h4 {
    font-size: 13px;
    font-weight: 500;
    margin-top: 5px;
}
    
}
@media (max-width: 1280px){
.items h4 {
    font-size: 13px;
    font-weight: 500;
}
    
}
body{
    text-transform: uppercase;
}
.sidebar-menu > li > a {
    color:#fff;
}
.sidebar-menu .treeview-menu > li > a:hover {
    color: #f38607;
}
.cardbox {
background-color: #ff4e00;
background-image: linear-gradient(315deg, #ff4e00 0%, #ec9f05 74%);

}
.btn-grad {
background-color: #ff4e00;
background-image: linear-gradient(315deg, #ff4e00 0%, #ec9f05 74%);

    
}
.items h4{
    color:#000;
}
.items i{
    color:#000;
}
         .btn-grad {
            margin: 0px;
            width:100%;
            padding: 10px 35px;
            text-align: center;
            text-transform: uppercase;
            transition: 0.5s;
            background-size: 200% auto;
            color: #000;            
            box-shadow: 0 0 20px #eee;
            border-radius: 10px;
            display: block;
          }

          .btn-grad:hover {
            background-position: right center; /* change the direction of the change here */
            color: #fff;
            text-decoration: none;
          }
          .header-title .breadcrumb {
    max-width: 180px;
          }
          .form-control {}
    #toTop {
    bottom: 50px;}
</style>