<?php
$company_url="https://imgguru.in/upi/admin/";
$base_url="https://imgguru.in/upi/";
$admin_url="https://imgguru.in/upi/admin/";
$favicon="$base_url/favicon.ico";
$company_logo="$base_url/logo.44f8f391090e0c2fa87d.png";
$owner_image="$base_url/logo.44f8f391090e0c2fa87d.png";
$cover_login="$base_url/images/logo.jpeg";
$company_name="Online Shopping Site for Mobiles, Electronics, Furniture, Grocery";
$company_owner="Shivam";
$company_phone="";
$self=$_SERVER['PHP_SELF'];
?>