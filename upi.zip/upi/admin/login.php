<?php
session_start();
if(isset($_SESSION['admin_username']))
{
	echo"
		<script type='text/javascript'>
		alert('Welcome Back! You are already in.');
		window.location.replace('index.php');
		</script>";
}
?>
<?php
if(isset($_POST['admin_submit'])){
$u=$_POST['username'];
$ps=$_POST['password'];
include 'connection.php';
$sql = "SELECT * FROM admin WHERE user_name='$u' and  password='$ps'";
$data=mysqli_query($con,$sql);
$total=mysqli_num_rows($data);
	if($total > 0 )
		{
		setcookie("admin_user","$u",time()+3600*24*30, '/');
		$_SESSION['admin_username']=$u;
		$_SESSION['login']=true;
		echo "<script type='text/javascript'>
		window.location.href = 'index.php';
		</script>" ;
		}
	else    
	{
		echo"
		<script type='text/javascript'>
		alert('Login fails! Please Try Again !');
		window.location.replace('login.php');
		</script>";
		//header("location:index.php");
		}
}
?>
<?php
include "info.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Admin Login Panel - <?php echo $company_name;?></title>

    <!-- Favicon and touch icons -->
    <link rel="shortcut icon" href="<?php echo $favicon;?>" type="image/x-icon">
    

    <!-- Bootstrap -->
    <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
    <!-- Bootstrap rtl -->
    <!--<link href="assets/bootstrap-rtl/bootstrap-rtl.min.css" rel="stylesheet" type="text/css"/>-->
    <!-- Pe-icon-7-stroke -->
    <link href="assets/pe-icon-7-stroke/css/pe-icon-7-stroke.css" rel="stylesheet" type="text/css"/>
    <!-- style css -->
    <link href="assets/dist/css/stylehealth.min.css" rel="stylesheet" type="text/css"/>
    <!-- Theme style rtl -->
    <!--<link href="assets/dist/css/stylehealth-rtl.css" rel="stylesheet" type="text/css"/>-->
    <style>
    @import url('https://fonts.googleapis.com/css?family=Exo:400,700');

*{
    margin: 0px;
    padding: 0px;
}

body{
    font-family: 'Exo', sans-serif;
}


.context {
    width: 100%;
    position: absolute;
    top:5vh;
    
}

.context h1{
    text-align: center;
    color: #fff;
    font-size: 50px;
}


.area{
    background-color: #ff4e00;
    background-image: linear-gradient(315deg, red 0%, #ec9f05 74%);
    width: 100%;
    height:100vh;
    
   
}

.circles{
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    overflow: hidden;
}

.circles li{
    position: absolute;
    display: block;
    list-style: none;
    width: 20px;
    height: 20px;
    background: rgba(255, 255, 255, 0.2);
    animation: animate 25s linear infinite;
    bottom: -150px;
    
}

.circles li:nth-child(1){
    left: 25%;
    width: 80px;
    height: 80px;
    animation-delay: 0s;
}


.circles li:nth-child(2){
    left: 10%;
    width: 20px;
    height: 20px;
    animation-delay: 2s;
    animation-duration: 12s;
}

.circles li:nth-child(3){
    left: 70%;
    width: 20px;
    height: 20px;
    animation-delay: 4s;
}

.circles li:nth-child(4){
    left: 40%;
    width: 60px;
    height: 60px;
    animation-delay: 0s;
    animation-duration: 18s;
}

.circles li:nth-child(5){
    left: 65%;
    width: 20px;
    height: 20px;
    animation-delay: 0s;
}

.circles li:nth-child(6){
    left: 75%;
    width: 110px;
    height: 110px;
    animation-delay: 3s;
}

.circles li:nth-child(7){
    left: 35%;
    width: 150px;
    height: 150px;
    animation-delay: 7s;
}

.circles li:nth-child(8){
    left: 50%;
    width: 25px;
    height: 25px;
    animation-delay: 15s;
    animation-duration: 45s;
}

.circles li:nth-child(9){
    left: 20%;
    width: 15px;
    height: 15px;
    animation-delay: 2s;
    animation-duration: 35s;
}

.circles li:nth-child(10){
    left: 85%;
    width: 150px;
    height: 150px;
    animation-delay: 0s;
    animation-duration: 11s;
}



@keyframes animate {

    0%{
        transform: translateY(0) rotate(0deg);
        opacity: 1;
        border-radius: 0;
    }

    100%{
        transform: translateY(-1000px) rotate(720deg);
        opacity: 0;
        border-radius: 50%;
    }

}


         .btn-grad {
             
             background-color: #ff4e00;
background-image: linear-gradient(315deg, #ff4e00 0%, #ec9f05 74%);
         }
         .btn-grad {
            margin: 0px;
            width:100%;
            padding: 10px 35px;
            text-align: center;
            text-transform: uppercase;
            transition: 0.5s;
            background-size: 200% auto;
            color: white;            
            box-shadow: 0 0 20px #eee;
            border-radius: 10px;
            display: block;
          }

          .btn-grad:hover {
            background-position: right center; /* change the direction of the change here */
            color: #fff;
            text-decoration: none;
          }
         


    </style>
</head>
<body>
     <div class="area" >
            <ul class="circles">
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
            </ul>
    </div >

    
    <!-- Content Wrapper -->
    <div class="login-wrapper context" style="padding: 4px 17px;">
          <div class="container-center" style="margin: 0% auto 0;">
            <div class="panel panel-bd">
				<center><br><img src="<?php echo $company_logo;?>" style="width:40%;"></center>
                <div class="panel-heading">
                    <div class="view-header">
                        <div class="header-icon">
                            <i class="pe-7s-unlock"></i>
                        </div>
                        <div class="header-title">
                            <h3>Admin Login</h3>
                            <small><strong>Please enter your credentials to login.</strong></small>
                        </div>
                    </div>
                </div>
                <div class="panel-body">
                    <form method="post" action="<?php echo "$self"; ?>" id="loginForm" >
                        <div class="form-group">
                            <label class="control-label" for="username">Username</label>
                            <input type="text" placeholder="Enter Your Username" title="Please enter you username" required="yes" value="" name="username" id="username" class="form-control">
                            <span class="help-block small">Your unique username to app</span>
                        </div>
                        <div class="form-group">
                            <label class="control-label" for="password">Password</label>
                            <input type="password" title="Please enter your password" placeholder="******" required="" value="" name="password" id="password" class="form-control">
                            <span class="help-block small">Your strong password</span>
                        </div>
                        
                        <div>
                            <button class="btn btn-grad"  type="submit" name="admin_submit">Login</button>
                            
                        </div>
                    </form>
                </div>
            </div>
        </div>
<center style="text-shadow:1px 1px 5px #000;color:#fff;"><strong>&copy; 2022-<?php echo date('Y'); ?>. <?php echo $company_name;?>.</strong> All rights reserved. Developed By <a style="color:#fff;text-decoration:none;font-weight:bolder;" href="https://www.raksasolution.com/" target="_blank">Raksa Solution</a> </center>
    </div>
    <!-- /.content-wrapper -->
    <!-- jQuery -->
    <script src="assets/plugins/jQuery/jquery-1.12.4.min.js" type="text/javascript"></script>
    <!-- bootstrap js -->
    <script src="assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
</body>
   
</html>
