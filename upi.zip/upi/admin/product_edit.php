<?php
ob_start();
include 'check-login.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php
include 'header.php';
?>
<title>Edit Product - <?php echo $company_name;?></title>

<style>
ul#ui-id-1 {
    background: #fff;
}
</style>

<script src="https://cdn.ckeditor.com/4.11.1/standard-all/ckeditor.js"></script>
</head>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
<?php
include 'top-nav.php';
?>
<?php
    include 'sidebar-left.php';
    include 'connection.php';
?>

<?php

if(isset($_GET['edit'])){
    $edit = $_GET['edit'];
    $query = "SELECT * FROM `product` WHERE `id` = $edit";
    $result = mysqli_query($con , $query);
    while($row_data = mysqli_fetch_array($result)){
        $name = $row_data['name'];
        $category = $row_data['category'];
        $distributor_price = $row_data['distributor_price'];
        $dealer_price = $row_data['dealer_price'];
        $mrp_price = $row_data['mrp_price'];
        $selling_price = $row_data['selling_price'];
        $description = $row_data['description'];
        $stock = $row_data['stock'];
        $image = $row_data['image'];
        $featured = $row_data['featured'];
    }
}
if(isset($_POST['add_city'])){
    $id = $_GET['edit'];
    $cat_name = $_POST['cat_name'];
    $product_name = $_POST['product_name'];
    $distributor_price = $_POST['distributor_price'];
    $dealer_price = $_POST['dealer_price'];
    $mrp_price = $_POST['mrp_price'];
    $selling_price = $_POST['selling_price'];
    $sub_desc = $_POST['sub_desc'];
    $stock = $_POST['stock'];
    $featured_product = $_POST['featured_product'];
    $main_icon=$_FILES["fileToUpload"]["name"];
    $target_dir = '../images/product/';
    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
        
    $extension = pathinfo($_FILES["fileToUpload"]["name"], PATHINFO_EXTENSION);
        
    if($main_icon != ''){
        if($extension=='jpg' || $extension=='jpeg' || $extension=='png' || $extension=='gif')
        {
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)){
            $run = mysqli_query($con, "UPDATE `product` SET `name`= '$product_name' ,`category`= '$cat_name', `distributor_price` = '$distributor_price' ,`dealer_price`= '$dealer_price' ,`mrp_price`= '$mrp_price',`selling_price`= '$selling_price',`description`= '$sub_desc',`stock`= '$stock', `image` = '$main_icon' , `featured` = '$featured_product' WHERE `id` = $id" );
            if($run)
            {
              echo "<script>alert('Product updated sucessfully !');</script>" ;	
            }
            else
            {
            	 echo "<script>alert('File is Not Image !');</script>" ;	
            }
                }
                    }
    }
    else{
        $sql ="UPDATE `product` SET `name`= '$product_name' ,`category`= '$cat_name', `distributor_price` = '$distributor_price' ,`dealer_price`= '$dealer_price' ,`mrp_price`= '$mrp_price',`selling_price`= '$selling_price',`description`= '$sub_desc',`stock`= '$stock' , `featured` = '$featured_product'  WHERE `id` = $id";
        $run = mysqli_query($con, $sql);
        if($run)
        {
             echo "<script>alert('Product updated sucessfully !');</script>" ;	
        }
        else
        {
            echo "<script>alert('Some Error !');</script>" ;	
        }
   
       
        }
}
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
                <!-- Content Header (Page header) -->
               <section class="content-header">
                    <div class="header-icon"><i class="fa fa-shopping-bag"></i></div>
                    <div class="header-title">
                        <h1>Edit Product</h1>
                        <small>Here you can Edit product.</small>
                        <ol class="breadcrumb hidden-xs">
                            <li><a href="index.php"><i class="pe-7s-home"></i>Home</a></li>
                            <li class="active">Product</li>
                        </ol>
                    </div>
                </section>
				    <!-- Main content -->
                <section class="content">
                    <div class="row">
                        <!-- Form controls -->
                        <div class="col-sm-12">
                            <div class="panel panel-bd lobidrag">
                                <div class="panel-heading">
                                    <div class="btn-group"> 
                                    </div>
                                </div>
                                <div class="panel-body">
                                	<div class="col-sm-12">
                                    	<form method="post" enctype="multipart/form-data">
                                    	
                                    	<div class="form-group">
                                    	    <label>Select Category*</label>
                                    	    <select class="form-control" name="cat_name">
                                    	        <?php
                                    	        $query = "SELECT * FROM `category`";
                                                $result = mysqli_query($con , $query);
                                                while($row = mysqli_fetch_array($result)){
                                                    ?>
                                                    <option value="<?= $row['cat_id'];?>"  <?php if($category == $row['cat_id']){ echo "selected";}?>><?= $row['cat_name'];?></option>
                                                    <?php
                                                }
                                    	        ?>
                                    	        
                                    	    </select>
                                    	</div>
                                    	
                                    	<div class="form-group">
                                    	    <label>Enter Product Name*</label>
                                    	    <input type="text" class="form-control" placeholder="Enter Product Name" required="yes" value="<?= $name;?>" name="product_name" >
                                    	</div>
                                    	
                                    	<div class="form-group">
                                    	    <label>Enter Distributor Price*</label>
                                    	    <input type="number" class="form-control" placeholder="Enter Distributor Name" required="yes" value="<?= $distributor_price;?>"  name="distributor_price">
                                    	</div>
                                    	
                                    	<div class="form-group">
                                    	    <label>Enter Dealer Price*</label>
                                    	    <input type="number" class="form-control" placeholder="Enter Dealer Name" required="yes" value="<?= $dealer_price;?>"  name="dealer_price">
                                    	</div>
                                    	
                                    	<div class="form-group">
                                    	    <label>Enter MRP Price*</label>
                                    	    <input type="number" class="form-control" placeholder="Enter MRP Name" required="yes" value="<?= $mrp_price;?>"  name="mrp_price">
                                    	</div>
                                    	
                                    	<div class="form-group">
                                    	    <label>Enter Selling Price*</label>
                                    	    <input type="number" class="form-control" placeholder="Enter Selling Name" required="yes" value="<?= $selling_price;?>"  name="selling_price">
                                    	</div>
                                    	
                                    	<div class="form-group">
                                    	    <label>Enter Stock*</label>
                                    	    <input type="number" class="form-control" placeholder="Enter Stock" required="yes" value="<?= $stock;?>"  name="stock">
                                    	</div>
                                    	
                                        <div class="form-group">
                                            <label>Enter Product Description*</label>
                                            <textarea type="textarea" class="form-control" id="editor1" placeholder="Enter Product Description" required="yes" name="sub_desc" ><?= $description;?></textarea>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label>Select Product Image*</label>
                                            <input type="file" class="form-control" name="fileToUpload" id="fileToUpload" accept="image/*;capture=camera" >
                                        </div>
                                        
                                        <div class="form-group">
                                    	    <label>Featured Product</label>
                                    	    <select class="form-control" name="featured_product">
                                    	        <option value="">Select Product</option>
                                    	        <option value="Yes" <?php if($featured == 'Yes'){ echo "selected";}?>>Yes</option>
                                    	        <option value="No"  <?php if($featured == 'No'){ echo "selected";}?>>No</option>
                                    	    </select>
                                    	</div>
                                    	
                                    	<div style="margin-bottom: 15px;">
                                    	    <button class="btn btn-success" type="submit" name="add_city">Submit</button>
                                    	</div>
                                    	</form>
                                	</div>
                                </div>
                                 </div>
                             </div>
                         </div>
                     </section> <!-- /.content -->
				    <!-- Main content -->
               
</div> <!-- /.content-wrapper -->
<?php
include 'footer.php';
?>
</div> <!-- ./wrapper -->

<?php
include 'footer-script.php';
?>	


<script>
    CKEDITOR.addCss('figure[class*=easyimage-gradient]::before { content: ""; position: absolute; top: 0; bottom: 0; left: 0; right: 0; }' +
      'figure[class*=easyimage-gradient] figcaption { position: relative; z-index: 2; }' +
      '.easyimage-gradient-1::before { background-image: linear-gradient( 135deg, rgba( 115, 110, 254, 0 ) 0%, rgba( 66, 174, 234, .72 ) 100% ); }' +
      '.easyimage-gradient-2::before { background-image: linear-gradient( 135deg, rgba( 115, 110, 254, 0 ) 0%, rgba( 228, 66, 234, .72 ) 100% ); }');

CKEDITOR.replace('editor1', {
      extraPlugins: 'easyimage',
      removePlugins: 'image',
      removeDialogTabs: 'link:advanced',
      toolbar: [{
          name: 'document',
          items: ['Undo', 'Redo']
        },
        {
          name: 'styles',
          items: ['Format']
        },
        {
          name: 'basicstyles',
          items: ['Bold', 'Italic', 'Strike', '-', 'RemoveFormat']
        },
        {
          name: 'paragraph',
          items: ['NumberedList', 'BulletedList']
        },
        {
          name: 'links',
          items: ['Link', 'Unlink']
        },
        {
          name: 'insert',
          items: ['EasyImageUpload']
        }
      ],
      height: 200,
      cloudServices_uploadUrl: 'https://33333.cke-cs.com/easyimage/upload/',
     
      cloudServices_tokenUrl: 'https://33333.cke-cs.com/token/dev/ijrDsqFix838Gh3wGO3F77FSW94BwcLXprJ4APSp3XQ26xsUHTi0jcb1hoBt',
      easyimage_styles: {
        gradient1: {
          group: 'easyimage-gradients',
          attributes: {
            'class': 'easyimage-gradient-1'
          },
          label: 'Blue Gradient',
          icon: 'https://ckeditor.com/docs/ckeditor4/4.11.1/examples/assets/easyimage/icons/gradient1.png',
          iconHiDpi: 'https://ckeditor.com/docs/ckeditor4/4.11.1/examples/assets/easyimage/icons/hidpi/gradient1.png'
        },
        gradient2: {
          group: 'easyimage-gradients',
          attributes: {
            'class': 'easyimage-gradient-2'
          },
          label: 'Pink Gradient',
          icon: 'https://ckeditor.com/docs/ckeditor4/4.11.1/examples/assets/easyimage/icons/gradient2.png',
          iconHiDpi: 'https://ckeditor.com/docs/ckeditor4/4.11.1/examples/assets/easyimage/icons/hidpi/gradient2.png'
        },
        noGradient: {
          group: 'easyimage-gradients',
          attributes: {
            'class': 'easyimage-no-gradient'
          },
          label: 'No Gradient',
          icon: 'https://ckeditor.com/docs/ckeditor4/4.11.1/examples/assets/easyimage/icons/nogradient.png',
          iconHiDpi: 'https://ckeditor.com/docs/ckeditor4/4.11.1/examples/assets/easyimage/icons/hidpi/nogradient.png'
        }
      },
      easyimage_toolbar: [
        'EasyImageFull',
        'EasyImageSide',
        'EasyImageGradient1',
        'EasyImageGradient2',
        'EasyImageNoGradient',
        'EasyImageAlt'
      ]
    });

</script>

</body>
</html>