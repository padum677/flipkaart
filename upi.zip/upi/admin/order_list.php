<?php
include 'check-login.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php
include 'header.php';
?>
<title>App Order List - <?php echo $company_name;?></title>

<style>
    .act_btn
    {
        background: #e5343d;
        color: #fff;
        padding: 4px 10px;
        line-height: 37px;
    }
	.top_search
	{
		max-width: 300px;
		float: right;
	}
	.main_image 
	{
     height: 100px;
     width: 110px;
    }
    tr td {
        font-weight:bolder;
    }
</style>

</head>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
<?php
include 'top-nav.php';
?>
<?php
include 'sidebar-left.php';
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
                <!-- Content Header (Page header) -->
               <section class="content-header">
                    <div class="header-icon"><i class="fa fa-phone"></i></div>
                    <div class="header-title">
                        
                    
                        
                        <h1>App Order List</h1>
                        <small>Here you can view app Order List.</small>
                        <ol class="breadcrumb hidden-xs">
                            <li><a href="index.php"><i class="pe-7s-home"></i>Home</a></li>
                            <li class="active">Order</li>
                        </ol>
                    </div>
                </section>
				            <!-- Main content -->
                    <section class="content">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                  
                                    <div class="panel-body">
                                       
                                          <div class="table-responsive">
                                            <table class="table table-bordered table-hover" id="session">
                                                <thead>
                                                    <tr>
                                                        <th>Sr.No</th>
                                                        <th>Order ID</th>
                                                        <th>Order Date</th>
                                                        <th>Total Amount</th>
                                                        <th>User Name</th>
                                                        <th>Remark</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
<?php	
$i=1;
include 'connection.php';
if(isset($_POST['submit_remark'])){
    $order_id=$_POST["order_id"];
    $remark=$_POST["remark"];
    $sql = "UPDATE `orders` SET `remark`= '$remark' WHERE `id` = $order_id";
    $run = mysqli_query($con, $sql);
    if($run)
    { echo "<script>alert('Remark update sucessfully !');</script>" ;	}
    else{ echo "<script>alert('Some Error !');</script>" ;	}
}

if(isset($_GET['value']))
{
    $value = $_GET['value'];
    $id = $_GET['id'];
    mysqli_query($con,"UPDATE `orders` SET `status` = '$value' WHERE id = '$id' ");
    header('location:order_list.php');
}

if(isset($_GET['delete']))
{
    $del_id = $_GET['delete'];
    mysqli_query($con,"DELETE from orders WHERE id=$del_id");
    header('location:order_list.php');
}

$query1 = "SELECT * FROM orders WHERE user_type = '3' order by id DESC";
$result2 = mysqli_query($con , $query1);
while($row = mysqli_fetch_array($result2))
  {
	$order_id = $row['id'];
	$total = $row['total'];
	$user_id=$row['user_id'];
	$status=$row['status'];
	$created = $row['created'];
	$get_remark = $row['remark'];
	
  
    $query = "SELECT * FROM users WHERE id = $user_id";
    $result = mysqli_query($con , $query);
    while($rows = mysqli_fetch_array($result))
    {
      $full_name = $rows['full_name'];
    }
    
    if($status == 1){
        $sts = 'Pending';
    }
    if($status == 2){
        $sts = 'Shipped';
    }
    if($status == 0){
        $sts = 'Cancelled';
    }
?>											
<tr style="background:<?php if($status == '1'){ echo "#fff;color:#000;";} if($status == '2'){ echo "#76b300;color:#000;";} else {echo "orange;color:#000;";} ?> " >  
<td><label><?php echo $i;?></label></td>
<td><label>#<?php echo $order_id;?></label></td>
<td><?php echo date('d M-y h:i A', strtotime($created));?></td>
<td><i class="fa fa-inr" aria-hidden="true"></i><?php echo $total ;?></td>
<td><?php echo $full_name;?></td>
<td><?php echo $get_remark;?></td>
<td data-id="<?php echo $order_id; ?>"  style="text-align: center;">
    <span><?php echo $sts; ?>
    </span>
<select class="form-control status" name="status">
    <option value="1" <?php if($status == '1'){ echo "selected";}?>>Pending</option>
    <option value="2" <?php if($status == '2'){ echo "selected";}?>>Shipped</option>
    <option value="0" <?php if($status == '0'){ echo "selected";}?>>Cancelled</option>
</select>
</td>
<td>
<button type="button" class="btn btn-danger btn-xs del_btn" data-id="<?php echo $order_id;?>" data-toggle="modal" data-target="#ordine"><i class="fa fa-trash-o"></i> DELETE</button>
<a href="view_order.php?view=<?= $order_id;?>" class="btn btn-xs btn-info"><i class="fa fa-eye" aria-hidden="true"></i> VIEW ORDER</a>
<button type="button" class="btn btn-info btn-xs" data-toggle="modal" data-target="#myModal_<?= $order_id;?>">ADD REMARK</button>
  
  <!-- Modal -->
  <div class="modal fade" id="myModal_<?= $order_id;?>" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add Remark</h4>
        </div>
        <div class="modal-body">
          <form method="POST">
              <input type="hidden" value="<?= $order_id;?>" name="order_id">
              <input type="text" name="remark" class="form-control">
              <input type="submit" class="btn btn-info" name="submit_remark" style="margin-top: 20px;">
          </form>
        </div>
        
      </div>
      
    </div>
  </div>
  
</td>
</tr>
<?php
$i++;
}
mysqli_close($con);
?>
                                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
        </div>
        
    </div>
</section> <!-- /.content -->
               
</div> <!-- /.content-wrapper -->
<?php
include 'footer.php';
?>
</div> <!-- ./wrapper -->

<?php
include 'footer-script.php';
?>

<script>
$(document).ready(function(){
$('body').on('change', '.status', function(){
//('.status').on('change', function() {
  var get_value = this.value ;
  var get_id = $(this).closest('td').attr("data-id");
  window.location.href = "order_list.php?value="+get_value+"&id="+get_id;
});
$('body').on('click', '.del_btn', function(){
//$(".del_btn").click(function(){
    var id = $(this).attr('data-id');
    if (confirm("Do you want to delete"))
    {
        window.location.href = "order_list.php?delete="+id;
    }
    else
    {
        return false;
    }
  });
});
</script>

</body>
</html>