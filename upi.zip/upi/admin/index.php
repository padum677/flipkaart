<?php
include 'check-login.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php
include 'header.php';
?>
<title>Homepage | <?php echo $company_name;?></title>
</head>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
<?php
include 'top-nav.php';
?>
<?php
include 'sidebar-left.php';

$total_product_query = "SELECT * FROM product";
$select_product_result = mysqli_query($con , $total_product_query);
$totalproduct = mysqli_num_rows($select_product_result);

?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <div class="header-icon">
                        <i class="fa fa-tachometer"></i>
                    </div>
                    <div class="header-title">
                        <h1> Dashboard</h1>
                        <small> Dashboard contain all data value.</small>
                        <ol class="breadcrumb hidden-xs">
                            <li><a href="index.php"><i class="pe-7s-home"></i> Home</a></li>
                            <li class="active">Dashboard</li>
                        </ol>
                    </div>
                </section>
                <section class="content">
                    <div class="row">
                        
                        <div class="col-xs-6 col-sm-6 col-md-6 col-lg-3" onclick="location.href='product_list.php';">
                            <div class="panel panel-bd cardbox">
                                <div class="panel-body">
                                    <div class="statistic-box">
                                        <h2><span class="count-number"><?= $totalproduct;?></span>
                                        </h2>
                                    </div>
                                    <div class="items pull-left">
                                        <i class="fa fa-shopping-bag fa-2x"></i>
                                        <h4>Products</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    
                    </div>
                <!-- /.row -->
                </section> <!-- /.content -->
</div> <!-- /.content-wrapper -->
<?php
include 'footer.php';
?>
</div> <!-- ./wrapper -->

<?php
include 'footer-script.php';
?>		
</body>
</html>