     <!-- Left side column. contains the sidebar -->
          <aside class="main-sidebar" style="background-color:#000;">
                <!-- sidebar -->
                <div class="sidebar">
                    <!-- Sidebar user panel -->
                    <div class="user-panel" style="border-bottom: 2px solid #fff;background: #fff;padding: 0px;">
                        <div class="image pull-left">
                            <img src="<?php echo $owner_image;?>" alt="User Image" style="max-width: 100px;">
                        </div>
                        <div class="info" style="margin-top: 36px;">
                            <h4 style="color:#000;">Welcome</h4>
                            <p style="color:#000;"><?php echo $company_owner;?></p>
                        </div>
                    </div>
                   
                    <!-- sidebar menu -->
                    <ul class="sidebar-menu" style="background-color:#000;">
                        <li><a href="index.php"><i class="fa fa-home"></i><span>Dashboard</span></a></li>
                    
                        
                        <li class="treeview">
						<a href="#">
						<i class="fa fa-shopping-bag"></i><span>Product</span>
						<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
						</span>
						</a>
						<ul class="treeview-menu">
						<li><a href="product_add.php">Add Product</a></li>
						<li><a href="product_list.php">All Product</a></li>
						</ul>
						</li> 
						
     
                        <li><a href="change_pass.php"><i class="fa fa-key"></i><span>Change Admin Password</span></a></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out"></i><span>Logout</span></a></li>
                   </ul>
        </div> 
    </aside>
            <!-- =============================================== -->