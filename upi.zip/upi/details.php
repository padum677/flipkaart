<?php 
include 'cart_code.php';
?>
<html>
    <head>
        <title>Online Shopping Site for Mobiles, Electronics, Furniture, Grocery...</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="header.css">
        <link rel="stylesheet" href="home.css">
        <link rel="stylesheet" href="prdt.css">
        <link rel="apple-touch-icon" href="logo192.png">
        <link rel="icon" href="favicon.ico">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <div class="header2">
          <div class="hamicon"><i class="fa fa-arrow-left"></i></div>
          <div class="cart"><i class="fa fa-search"></i><i class="fa fa-bell"><span>1</span></i><i
              class="fa fa-shopping-cart"><span>
                  <?php 
                   if(isset($_SESSION['shopping_cart'])){
                       echo count($_SESSION['shopping_cart']);
                   }else{
                       echo "0";
                   }
                  ?>
              </span></i></div>
        </div>
        
<?php
include 'admin/connection.php';
$pro_id = $_GET['id'];
$query1 = "SELECT * FROM product WHERE id = $pro_id";
$result2 = mysqli_query($con , $query1);
while($row = mysqli_fetch_array($result2)){
    $name=$row['name'];
    $mrp_price=$row['mrp_price'];
    $image = $row['image'];
    $selling_price = $row['selling_price'];
    $gallery = json_decode($row['gallery'] , true);
    $discount_price = $mrp_price - $selling_price;
}
?>      
<div class="pview">
  
           <div id="myCarousel" class="carousel slide" data-ride="carousel">
                    <!-- Indicators -->
                    <ol class="carousel-indicators">
                        <?php 
                          foreach($gallery as $key => $value){
                              ?>
                            <li data-target="#myCarousel" data-slide-to="<?= $key;?>" class="<?php if($key==0){ echo "active";}?>"></li>
                              <?php
                          }
                         ?>
                         
                    </ol>
                
                    <!-- Wrapper for slides -->
                    <div class="carousel-inner">
                        <?php 
                          foreach($gallery as $key => $value){
                              ?>
                            <div class="item <?php if($key==0){ echo "active";}?>">
                                <img src="<?= $value;?>" alt="Los Angeles">
                            </div>
                              <?php
                          }
                         ?>
                    </div>
                
            </div>
    

    <form method="POST" style="display: contents;" class="cart_form">
    <div class="ec-single-cart">
            <input type="hidden" name="product_id" value="<?php echo $pro_id; ?>" />
            <input type="hidden" name="hidden_img" value="<?php echo $image; ?>" />
            <input type="hidden" name="hidden_name" value="<?php echo $name; ?>" />
            <input type="hidden" name="hidden_price" value="<?php echo $selling_price; ?>" />
            <input type="hidden" name="quantity"   value="1" />
            <input type="hidden" name="quity_select"   value="<?=$mrp_price;?>" />
    </div>
    <div class="buttons">
       <button type="submit" name="add_to_cart" class="add_tocart">ADD TO CART</button>
       <button type="submit" name="add_to_cart" class="buynow">BUY NOW</button>
      <!--<a href="javascript:void(0);" name="add_to_cart" ></a><a href="javascript:void(0);" name="add_to_cart">BUY NOW</a>-->
    </div>
    </form>
    
 
  <div class="detail">
    <p class="name"><?= $name;?></p>
    <p class="rating"><span>4.6 ★</span>4,063 ratings</p>
    <div class="price">
      <p class="off"><?php echo number_format(($discount_price / $mrp_price) * 100);?>% off</p>
      <p class="cut"><?= number_format($mrp_price);?></p>
      <p class="original">₹<?= $selling_price;?></p>
    </div>
    <div class="delivery">
      <p>FREE Delivery <span>| Delivery within 7 Days</span></p>
    </div>
    <div class="cod"></div><img src="" alt=""><img src="" alt=""><img src="" alt="">
    <div class="offer">
      <p class="coupon">Coupons for you</p>
      <p class="sp"><span>Special Price </span>Get extra 30% off upto ₹50 on 1 item(s) (price inclusive of discount)
        <span style="color: blue; text-decoration: underline;">T&amp;C</span></p>
      <p class="available">Available offers</p>
      <ul>
        <li><span>Bank offer </span>Additional ₹2000 off on HDFC Bank Credit Card <span
            style="color: blue; text-decoration: underline; font-weight: 600;">T&amp;C</span><i class="fa fa-tag"
            style="color: rgb(56, 142, 60); margin-left: 8px;"></i></li>
        <li><span>Partner offer </span>Buy this product and get upto ₹500 off on Flipkart Furniture <span
            style="color: blue; text-decoration: underline; font-weight: 600;">Know More</span><i class="fa fa-tag"
            style="color: rgb(56, 142, 60); margin-left: 8px;"></i></li>
        <li><span>Partner offer </span>Sign up for Flipkart Pay Later and Get Flipkart Gift Card worth ₹100 <span
            style="color: blue; text-decoration: underline; font-weight: 600;">Know More</span><i class="fa fa-tag"
            style="color: rgb(56, 142, 60); margin-left: 8px;"></i></li>
      </ul>
    </div>
    <p style="margin-top: 30px; font-weight: 600;">1 Year Warranty <span
        style="color: blue; text-decoration: underline; font-weight: 600;">Know More</span></p>
    <p style="margin-top: 30px; color: gray;">Terms &amp; Conditions</p>
  </div>
</div>

    </body>
</html>