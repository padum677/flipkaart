<?php
session_start();
if($_SESSION['admin_username'] == NULL)
{
	echo"
		<script type='text/javascript'>
		alert('Session Expired! Please Login Again');
		window.location.replace('login.php');
		</script>";
}
$user=$_SESSION['admin_username'];
$dir_sub="../app/uploads/sub-images/";
$dir_main="../app/uploads/main-icon/";
$dir_type="../app/uploads/type-images/";
$owner_name = "My Chetan";
?>