<?php
$dbhost='localhost';
$dbuser='imgguru_upidbu';
$dbpass='b{kx42$ibQV2';
$dbname='imgguru_upidb';
$con = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
?>