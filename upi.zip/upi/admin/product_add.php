<?php
ob_start();
include 'check-login.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php
include 'header.php';
?>
<title>Add Product - <?php echo $company_name;?></title>

<style>
ul#ui-id-1 {
    background: #fff;
}
</style>

<script src="https://cdn.ckeditor.com/4.11.1/standard-all/ckeditor.js"></script>
</head>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
<?php
include 'top-nav.php';
?>
<?php
    include 'sidebar-left.php';
    include 'connection.php';
?>

<?php
if(isset($_POST['add_city'])){
    
    $product_name = $_POST['product_name'];
    $mrp_price = $_POST['mrp_price'];
    $selling_price = $_POST['selling_price'];
    $sub_desc = $_POST['sub_desc'];
    $main_icon = $_POST['product_img'];
    $gal_img = json_encode($_POST['product_gal']);
    $status = 1;
    $created = date('Y-m-d H:i:s');
    
    $run = mysqli_query($con, "INSERT INTO `product`(`name`, `mrp_price`, `selling_price`, `description` ,`image`, `gallery` ,`status`, `created`) VALUES ('$product_name', '$mrp_price','$selling_price', '$sub_desc' ,'$main_icon', '$gal_img' ,'$status','$created')" );
    if($run)
    {
      echo "<script>alert('Data save sucessfully !');</script>" ;	
    }
    else
    {
    	echo "<script>alert('Some Error !');</script>" ;	
    }
}
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
                <!-- Content Header (Page header) -->
               <section class="content-header">
                    <div class="header-icon"><i class="fa fa-shopping-bag"></i></div>
                    <div class="header-title">
                       
                        <h1>Add Product</h1>
                        <small>Here you can add product.</small>
                        <ol class="breadcrumb hidden-xs">
                            <li><a href="index.php"><i class="pe-7s-home"></i>Home</a></li>
                            <li class="active">Product</li>
                        </ol>
                    </div>
                </section>
				    <!-- Main content -->
                <section class="content">
                    <div class="row">
                        <!-- Form controls -->
                        <div class="col-sm-12">
                            <div class="panel panel-bd">
                                <div class="panel-heading">
                                    <div class="btn-group"> 
                                    </div>
                                </div>
                                <div class="panel-body">
                                	<div class="col-sm-12">
                                    	<form method="post" action="<?php echo "$self"; ?>" enctype="multipart/form-data">
                                    	
                                    	<div class="form-group">
                                    	    <label>Enter Product Name*</label>
                                    	    <input type="text" class="form-control" placeholder="Enter Product Name" required="yes" name="product_name" >
                                    	</div>
                                    	
                                    	
                                    	<div class="form-group">
                                    	    <label>Enter MRP Price*</label>
                                    	    <input type="number" class="form-control" placeholder="Enter MRP Name" required="yes" name="mrp_price">
                                    	</div>
                                    	
                                    	<div class="form-group">
                                    	    <label>Enter Selling Price*</label>
                                    	    <input type="number" class="form-control" placeholder="Enter Selling Name" required="yes" name="selling_price">
                                    	</div>
                                    	
                                    	
                                    	
                                        <div class="form-group">
                                            <label>Enter Product Description*</label>
                                            <textarea type="textarea" class="form-control" id="editor1" placeholder="Enter Product Description" required="yes" name="sub_desc" ></textarea>
                                        </div>
                                        
                                        <div class="form-group">
                                            <label>Select Product Image Link*</label>
                                            <input type="text" class="form-control" name="product_img">
                                        </div>
                                        
                                        <div class="form-group">
                                            <label>Product Gallery Image Link 1*</label>
                                            <input type="text" class="form-control" name="product_gal[]">
                                        </div>
                                        
                                        <div class="form-group">
                                            <label>Product Gallery Image Link 2*</label>
                                            <input type="text" class="form-control" name="product_gal[]">
                                        </div>
                                        
                                        <div class="form-group">
                                            <label>Product Gallery Image Link 3*</label>
                                            <input type="text" class="form-control" name="product_gal[]">
                                        </div>
                                        
                                        <div class="form-group">
                                            <label>Product Gallery Image Link 4*</label>
                                            <input type="text" class="form-control" name="product_gal[]">
                                        </div>
                                        
                                        
                                    	<div style="margin-bottom: 15px;">
                                    	    <button class="btn btn-success" type="submit" name="add_city">Submit</button>
                                    	</div>
                                    	</form>
                                	</div>
                                </div>
                                 </div>
                             </div>
                         </div>
                     </section> <!-- /.content -->
				    <!-- Main content -->
               
</div> <!-- /.content-wrapper -->
<?php
include 'footer.php';
?>
</div> <!-- ./wrapper -->

<?php
include 'footer-script.php';
?>	


<script>
    CKEDITOR.addCss('figure[class*=easyimage-gradient]::before { content: ""; position: absolute; top: 0; bottom: 0; left: 0; right: 0; }' +
      'figure[class*=easyimage-gradient] figcaption { position: relative; z-index: 2; }' +
      '.easyimage-gradient-1::before { background-image: linear-gradient( 135deg, rgba( 115, 110, 254, 0 ) 0%, rgba( 66, 174, 234, .72 ) 100% ); }' +
      '.easyimage-gradient-2::before { background-image: linear-gradient( 135deg, rgba( 115, 110, 254, 0 ) 0%, rgba( 228, 66, 234, .72 ) 100% ); }');

CKEDITOR.replace('editor1', {
      extraPlugins: 'easyimage',
      removePlugins: 'image',
      removeDialogTabs: 'link:advanced',
      toolbar: [{
          name: 'document',
          items: ['Undo', 'Redo']
        },
        {
          name: 'styles',
          items: ['Format']
        },
        {
          name: 'basicstyles',
          items: ['Bold', 'Italic', 'Strike', '-', 'RemoveFormat']
        },
        {
          name: 'paragraph',
          items: ['NumberedList', 'BulletedList']
        },
        {
          name: 'links',
          items: ['Link', 'Unlink']
        },
        {
          name: 'insert',
          items: ['EasyImageUpload']
        }
      ],
      height: 200,
      cloudServices_uploadUrl: 'https://33333.cke-cs.com/easyimage/upload/',
     
      cloudServices_tokenUrl: 'https://33333.cke-cs.com/token/dev/ijrDsqFix838Gh3wGO3F77FSW94BwcLXprJ4APSp3XQ26xsUHTi0jcb1hoBt',
      easyimage_styles: {
        gradient1: {
          group: 'easyimage-gradients',
          attributes: {
            'class': 'easyimage-gradient-1'
          },
          label: 'Blue Gradient',
          icon: 'https://ckeditor.com/docs/ckeditor4/4.11.1/examples/assets/easyimage/icons/gradient1.png',
          iconHiDpi: 'https://ckeditor.com/docs/ckeditor4/4.11.1/examples/assets/easyimage/icons/hidpi/gradient1.png'
        },
        gradient2: {
          group: 'easyimage-gradients',
          attributes: {
            'class': 'easyimage-gradient-2'
          },
          label: 'Pink Gradient',
          icon: 'https://ckeditor.com/docs/ckeditor4/4.11.1/examples/assets/easyimage/icons/gradient2.png',
          iconHiDpi: 'https://ckeditor.com/docs/ckeditor4/4.11.1/examples/assets/easyimage/icons/hidpi/gradient2.png'
        },
        noGradient: {
          group: 'easyimage-gradients',
          attributes: {
            'class': 'easyimage-no-gradient'
          },
          label: 'No Gradient',
          icon: 'https://ckeditor.com/docs/ckeditor4/4.11.1/examples/assets/easyimage/icons/nogradient.png',
          iconHiDpi: 'https://ckeditor.com/docs/ckeditor4/4.11.1/examples/assets/easyimage/icons/hidpi/nogradient.png'
        }
      },
      easyimage_toolbar: [
        'EasyImageFull',
        'EasyImageSide',
        'EasyImageGradient1',
        'EasyImageGradient2',
        'EasyImageNoGradient',
        'EasyImageAlt'
      ]
    });

</script>

</body>
</html>