<?php
include 'check-login.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php
include 'header.php';
?>

<title>Profile View - <?php echo $company_name;?></title>
</head>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
<?php
include 'top-nav.php';
?>
<?php
include 'sidebar-left.php';
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
                <!-- Content Header (Page header) -->
               <section class="content-header">
                    <div class="header-icon"><i class="pe-7s-gift"></i></div>
                    <div class="header-title">
                        <form action="#" method="get" class="sidebar-form search-box pull-right hidden-md hidden-lg hidden-sm">
                            <div class="input-group">
                                <input type="text" name="q" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                    <button type="submit" name="search" id="search-btn" class="btn"><i class="fa fa-search"></i></button>
                                </span>
                            </div>
                        </form>   
                        <h1>Your Profile View</h1>
                        <small>Here you can view your profile view.</small>
                        <ol class="breadcrumb hidden-xs">
                            <li><a href="index.php"><i class="pe-7s-home"></i>Dashboard</a></li>
                            <li class="active">Profile</li>
                        </ol>
                    </div>
                </section>
				            <!-- Main content -->
                    <section class="content">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                              
                                    </div>
                                    <div class="panel-body">
                                       <div class="table-responsive">
                                            <table class="table table-bordered table-hover">
                                                
                                                <tbody>
                                                <tr><td>1</td><td>Profile Name</td><td>Girjesh Sarvan Admin</td></tr>
                                                <tr><td>2</td><td>Phone</td><td>7905016703</td></tr>
                                                <tr><td>3</td><td>Email</td><td>contact@ghomesevices.com</td></tr>

                                                
                            </tbody>
                        </table>
                    </div>                    
                </div>
            </div>
            
        </div>
        
    </div>
</section> <!-- /.content -->
               
</div> <!-- /.content-wrapper -->
<?php
include 'footer.php';
?>
</div> <!-- ./wrapper -->

<?php
include 'footer-script.php';
?>		
</body>
</html>