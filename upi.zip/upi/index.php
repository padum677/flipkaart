<?php 
include 'cart_code.php';

if(isset($_SESSION['shopping_cart'])){
    session_destroy();
}
?>

<html>
    <head>
        <title>Online Shopping Site for Mobiles, Electronics, Furniture, Grocery...</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="header.css">
        <link rel="stylesheet" href="home.css">
        <link rel="apple-touch-icon" href="logo192.png">
        <link rel="icon" href="favicon.ico">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
        <div class="header">
          <div class="header1">
            <div class="hamicon"><i class="fa fa-bars"></i></div>
            <div class="logo"><img src="logo.44f8f391090e0c2fa87d.png" alt="" width="100px" height="80px"></div>
            <div class="cart"><i class="fa fa-bell"><span>1</span></i><i class="fa fa-shopping-cart"><span>0</span></i></div>
          </div>
          <div class="search"><i class="fa fa-search"></i><input type="search" name="" id=""
              placeholder="Search for Products, Brands and More"></div>
        </div>
        
        <div class="home">
          <div class="nav1"><img src="nav1.1abc699c79d4f07e6044.png" alt=""></div>
          <div class="nav2">
              
             <div id="myCarousel" class="carousel slide" data-ride="carousel">
                    <!-- Indicators -->
                    <ol class="carousel-indicators">
                      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                      <li data-target="#myCarousel" data-slide-to="1"></li>
                      <li data-target="#myCarousel" data-slide-to="2"></li>
                    </ol>
                
                    <!-- Wrapper for slides -->
                    <div class="carousel-inner">
                      <div class="item active">
                        <img src="https://rukminim1.flixcart.com/fk-p-flap/1600/270/image/09a2543cc172d8e4.jpg?q=20" alt="Los Angeles" style="width:100%;">
                      </div>
                
                      <div class="item">
                        <img src="https://rukminim1.flixcart.com/fk-p-flap/1600/270/image/eb8cdf7f12465d86.png?q=20" alt="Chicago" style="width:100%;">
                      </div>
                    
                      <div class="item">
                        <img src="https://rukminim1.flixcart.com/fk-p-flap/1600/270/image/b086f75214cff988.jpg?q=20" alt="New york" style="width:100%;">
                      </div>
                      
                      <div class="item">
                        <img src="https://rukminim1.flixcart.com/fk-p-flap/1600/270/image/28cd75263d68e2f6.jpg?q=20" alt="New york" style="width:100%;">
                      </div>
                      
                    </div>
                
                    <!-- Left and right controls -->
                    <!--<a class="left carousel-control" href="#myCarousel" data-slide="prev">-->
                    <!--  <span class="glyphicon glyphicon-chevron-left"></span>-->
                    <!--  <span class="sr-only">Previous</span>-->
                    <!--</a>-->
                    <!--<a class="right carousel-control" href="#myCarousel" data-slide="next">-->
                    <!--  <span class="glyphicon glyphicon-chevron-right"></span>-->
                    <!--  <span class="sr-only">Next</span>-->
                    <!--</a>-->
                 </div>
                 
          </div>
          
          <div class="nav2"><img src="home2.057b5de1af5c40f7e6b3.jpg" alt="" style="margin-bottom: 30px;"></div>
        </div>
        
        <div class="products">
  <div class="timer">
    <div class="time">
      <p>Deals of the Day</p>
      <p class="timeo"><i class="fa fa-clock-o"></i><span id="demo"></span></p>
    </div><button>SALE IS LIVE</button>
  </div>
  <div class="product">
      
    <?php 
     include 'admin/connection.php';
     
        $query1 = "SELECT * FROM product order by id desc";
        $result2 = mysqli_query($con , $query1);
        while($row = mysqli_fetch_array($result2)){
            $pro_id=$row['id'];
            $image=$row['image'];
            $name=$row['name'];
            $mrp_price=$row['mrp_price'];
            $selling_price = $row['selling_price'];
            
            $discount_price = $mrp_price - $selling_price;
            ?>
            <div class="prdt">
              <div class="prdt-imgs"><img
                  src="<?= $image;?>"
                  alt="" class="prdt-img"></div>
              <p class="name" style="display: initial;"><?= $name;?></p>
              <p class="cut"><span>₹<?= number_format($mrp_price);?> </span> <?php echo number_format(($discount_price / $mrp_price) * 100);?>% Off</p><img src="assured.a4d4e693c2dbeccc8f82.png" alt=""
                class="assured">
              <h2 class="price">Now ₹<?= $selling_price;?></h2><a href="details.php?id=<?= $pro_id;?>">ADD TO CART</a>
            </div>
            <?php
        }
    ?>
    
  </div>
</div>

<?php 
date_default_timezone_set("Asia/Calcutta");
$now = time();
$ten_minutes = $now + (20 * 60);
$endDate = date('M d, Y H:i:s', $ten_minutes);
?>
<script>
// Set the date we're counting down to
var countDownDate = new Date("<?= $endDate;?>").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();
    
  // Find the distance between now and the count down date
  var distance = countDownDate - now;
    
  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
  // Output the result in an element with id="demo"
  document.getElementById("demo").innerHTML = minutes + "m " + seconds + "s ";
    
  // If the count down is over, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "EXPIRED";
  }
}, 1000);
</script>
</body>
</html>