<?php
include 'check-login.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<?php
include 'header.php';
?>
<title>Product List - <?php echo $company_name;?></title>

<style>
    .act_btn
    {
        background: #e5343d;
        color: #fff;
        padding: 4px 10px;
        line-height: 37px;
    }
	.top_search
	{
		max-width: 300px;
		float: right;
	}
	.main_image 
	{
     height: 100px;
     width: 110px;
    }
</style>

</head>
<body class="hold-transition sidebar-mini">
<!-- Site wrapper -->
<div class="wrapper">
<?php
include 'top-nav.php';
?>
<?php
include 'sidebar-left.php';
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
                <!-- Content Header (Page header) -->
               <section class="content-header">
                    <div class="header-icon"><i class="fa fa-shopping-bag"></i></div>
                    <div class="header-title">
                        
                        
                        <h1>Product List</h1>
                        <small>Here you can view Product List.</small>
                        <ol class="breadcrumb hidden-xs">
                            <li><a href="index.php"><i class="fa fa-home"></i>Home</a></li>
                            <li class="active">Product</li>
                        </ol>
                    </div>
                </section>
				            <!-- Main content -->
                    <section class="content">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="panel panel-bd lobidrag">
                                    <div class="panel-heading">
                                        <div class="btn-group"> 
                                            <a class="btn btn-success" href="product_add.php"> <i class="fa fa-plus"></i> Add Product
                                            </a>  
                                        </div>        
                                    </div>
                                    <div class="panel-body">
                                       
                                          <div class="table-responsive">
                                            <table class="table table-bordered table-hover" id="prod_list">
                                                <thead>
                                                    <tr>
                                                        <th>Sr.No</th>
                                                        <th>Image</th>
                                                        <th>Product Name</th>
                                                        <th>MRP</th>
                                                        <th>Selling</th>
                                                        <th>Status</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <?php	
                                                $i=1;
                                                include 'connection.php';
                                                
                                                
                                                if(isset($_GET['dact']))
                                                {
                                                    $cid = $_GET['dact'];
                                                    mysqli_query($con,"UPDATE product SET status='0' WHERE id='$cid' ");
                                                    
                                                }
                                                
                                                if(isset($_GET['act']))
                                                {
                                                    $cid = $_GET['act'];
                                                    mysqli_query($con,"UPDATE product SET status='1' WHERE id='$cid' ");
                                                    
                                                }
                                                
                                                if(isset($_GET['delete']))
                                                {
                                                    $del_id = $_GET['delete'];
                                                    mysqli_query($con,"DELETE from product WHERE id='$del_id' ");
                                                    header('location:product_list.php');
                                                }
                                                
                                                $query1 = "SELECT * FROM product order by id desc";
                                                $result2 = mysqli_query($con , $query1);
                                                while($row = mysqli_fetch_array($result2))
                                                  {
                                                	$id=$row['id'];
                                                	$image=$row['image'];
                                                	$name=$row['name'];
                                                	$category=$row['category'];
                                                	$dealer_price=$row['dealer_price'];
                                                	$mrp_price=$row['mrp_price'];
                                                	$selling_price = $row['selling_price'];
                                                	$status = $row['status'];
                                                	$stock = $row['stock'];
                                                	$distributor_price = $row['distributor_price'];
                                                  
                                                    $cat_query = "SELECT * FROM category WHERE cat_id = $category";
                                                    $cat_result = mysqli_query($con , $cat_query);
                                                    while($cat_row = mysqli_fetch_array($cat_result))
                                                    {
                                                        $cat_name = $cat_row['cat_name'];
                                                    }
                                                ?>											
                                                <tr>  
                                                <td><label><?php echo $i;?></label></td>
                                                <td><img src="<?= $image;?>" style="height: 100px;width: 100px;"></td>
                                                <td><?php echo $name;?></td>
                                                <td><?php echo $mrp_price;?></td>
                                                <td><?php echo $selling_price;?></td>
                                                <td><?php if($status == '1'){echo "<span style='color:green;'>Active</span><br><a href='product_list.php?dact=$id' class='act_btn'>Inactive</a>";}else{echo "<span style='color:red;'>Inactive</span><br><a href='product_list.php?act=$id' class='act_btn'>Active</a>";}?></td>
                                                <td>
                                                
                                                <button type="button" class="btn btn-danger btn-xs del_btn" data-id="<?php echo $id;?>"><i class="fa fa-trash-o"></i> DELETE</button>
                                                </td>
                                                </tr>
                                                <?php
                                                $i++;
                                                }
                                                ?>
                                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            
        </div>
        
    </div>
</section> <!-- /.content -->
               
</div> <!-- /.content-wrapper -->
<?php
include 'footer.php';
?>
</div> <!-- ./wrapper -->

<?php
include 'footer-script.php';
?>

<script>
$(document).ready(function(){
    $('body').on('click', '.del_btn', function(){
  //$(".del_btn").click(function(){
    var id = $(this).attr('data-id');
    if (confirm("Do you want to delete"))
    {
        window.location.href = "product_list.php?delete="+id;
    }
    else
    {
        return false;
    }
  });
  

    $('#prod_list').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copyHtml5',
            'excelHtml5',
            'csvHtml5',
            'pdfHtml5'
        ]
    } );

});
</script>


</body>
</html>